
[![Build Status](https://travis-ci.org/DonaldMbara/Link-Online-Tutoring-App-.svg?branch=master)](https://travis-ci.org/DonaldMbara/Link-Online-Tutoring-App-)

[![codecov](https://codecov.io/gh/DonaldMbara/Link-Online-Tutoring-App-/branch/master/graph/badge.svg)](https://codecov.io/gh/DonaldMbara/Link-Online-Tutoring-App-)

# Link-Online-Tutoring-App
COMS3009A (SOFTWARE DESIGN)

An app that connects people who need help to tutors who are accomplished in a particular course (Stackoverflow format)

Team
Our Team Name is: Boolean Autocrats.

The Scrum Master: Mongezi @sweetmoh

